This archive contains a simple clock API developped using JavaScript and a simple use of it in a HTML file.

The API offers simple methods like starting a clock, stopping it, getting the time between both those actions in a String or in a TimeObject and finally, reinitializing it.

The last method which is subscribe() allows the user to define a specific behavior using the API.

To implement this API I drew my inspiration from the observer design pattern.

Since I needed only one callback function it's not exactly an observer design pattern but it's very similar.

In the future, if there is a diferent behavior that is needed, all I have to do is replace myCallBack variable and execution variable with respectively, an array of callback functions and an array of execution. 

The main dificulty I have encountered was to be able to notify my "oberver" of the changes every second. I was able to do so using the setInterval javascript function.

Hope you will enjoy this!   
